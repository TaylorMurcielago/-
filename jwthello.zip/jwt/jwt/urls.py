from django.conf.urls import url
 

from . import jwtviews
urlpatterns = [
    url('login/', jwtviews.obtain_jwt_token),
]